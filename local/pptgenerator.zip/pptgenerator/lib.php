<?php

defined('MOODLE_INTERNAL') || die;


/**
 * Menambahkan item navigasi ke menu kursus.
 *
 * @param navigation_node $navref
 * @param context_course $context
 */
function local_pptgenerator_extend_navigation_course($navref, $context) {
    global $PAGE;

    // Pastikan hanya menambahkan item jika kita berada di halaman kursus
    if ($context->contextlevel == CONTEXT_COURSE) {
        $node = $navref->find('localpptgenerator', navigation_node::TYPE_CUSTOM);

        if (!$node) {
            $node = $navref->add(get_string('pluginname', 'local_pptgenerator'),
                new moodle_url('/local/pptgenerator/index.php'), navigation_node::TYPE_CUSTOM);

            // Tampilkan item di menu kursus
            $node->showinflatnavigation = true;
        }
    }
}

/**
 * Mengambil dan menyimpan konfigurasi plugin.
 */
function local_pptgenerator_get_config() {
    global $DB;

    $config = $DB->get_records('local_pptgenerator_config');
    $settings = [];

    foreach ($config as $item) {
        $settings[$item->name] = $item->value;
    }

    return $settings;
}

function local_pptgenerator_save_config($data) {
    global $DB;

    foreach ($data as $name => $value) {
        $record = new stdClass();
        $record->name = $name;
        $record->value = $value;

        if ($DB->record_exists('local_pptgenerator_config', ['name' => $name])) {
            $DB->update_record('local_pptgenerator_config', $record);
        } else {
            $DB->insert_record('local_pptgenerator_config', $record);
        }
    }

    return true;
}

/**
 * Membuat dan menyimpan file PPT menggunakan PHP Presentation.
 *
 * @param string $title
 * @param string $content
 * @param string|null $outline
 * @param string $template
 * @return string Path file PPT yang dibuat
 */
function local_pptgenerator_create_ppt($title, $content, $outline = null, $template = 'default') {
    // Memuat autoload.php untuk PHP Presentation
    require_once(__DIR__ . '/../../vendor/autoload.php');

    // Mendefinisikan class dari PHP Presentation tanpa use keyword
    $ppt = new \PhpOffice\PhpPresentation\PhpPresentation();

    // **Slide 1: Title Slide**
    $slide = $ppt->createSlide();
    $shape = $slide->createTextBox();
    $shape->setText($title);
    $shape->getAlignment()->setHorizontal(\PhpOffice\PhpPresentation\Style\Alignment::HORIZONTAL_CENTER);

    // **Slide 2: Content Slide**
    $slide = $ppt->createSlide();
    $shape = $slide->createTextBox();
    $shape->setText($content);
    $shape->getAlignment()->setHorizontal(\PhpOffice\PhpPresentation\Style\Alignment::HORIZONTAL_LEFT);

    // **Outline Slide (Optional)**
    if ($outline) {
        $outlinePoints = explode("\n", $outline);
        foreach ($outlinePoints as $point) {
            if (!empty(trim($point))) {
                $slide = $ppt->createSlide();
                $shape = $slide->createTextBox();
                $shape->setText($point);
                $shape->getAlignment()->setHorizontal(\PhpOffice\PhpPresentation\Style\Alignment::HORIZONTAL_LEFT);
            }
        }
    }

    // Apply Template (Basic Example)
    if ($template === 'business') {
        // Apply business style modifications here
    } elseif ($template === 'education') {
        // Apply education style modifications here
    }

    // Save the presentation
    $writer = \PhpOffice\PhpPresentation\IOFactory::createWriter($ppt, 'PowerPoint2007');
    $filePath = __DIR__ . '/generated_presentation.pptx';
    $writer->save($filePath);

    return $filePath;
}
