<?php
namespace local_pptgenerator;

class ppt_generator {
    public static function generate_ppt($title, $content, $outline, $template) {
        // Panggil fungsi create_ppt dari lib.php atau implementasikan di sini
        require_once(__DIR__ . '/../lib.php');
        return create_ppt($title, $content, $outline, $template);
    }
}
