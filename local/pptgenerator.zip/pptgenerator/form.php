<?php
require_once($CFG->libdir . '/formslib.php');

class ppt_generator_form extends moodleform {

    public function definition() {
        $mform = $this->_form;

        // Judul Presentasi
        $mform->addElement('text', 'title', get_string('ppt_title', 'local_pptgenerator'));
        $mform->setType('title', PARAM_NOTAGS);
        $mform->addRule('title', null, 'required', null, 'client');

        // Konten Slide
        $mform->addElement('textarea', 'content', get_string('ppt_content', 'local_pptgenerator'), 'wrap="virtual" rows="10" cols="50"');
        $mform->setType('content', PARAM_TEXT);
        $mform->addRule('content', null, 'required', null, 'client');

        // Outline (Opsional)
        $mform->addElement('textarea', 'outline', get_string('ppt_outline', 'local_pptgenerator'), 'wrap="virtual" rows="10" cols="50"');
        $mform->setType('outline', PARAM_TEXT);

        // Template
        $templates = array(
            'default' => get_string('default_template', 'local_pptgenerator'),
            'business' => get_string('business_template', 'local_pptgenerator'),
            'education' => get_string('education_template', 'local_pptgenerator'),
        );
        $mform->addElement('select', 'template', get_string('ppt_template', 'local_pptgenerator'), $templates);
        $mform->setType('template', PARAM_ALPHA);

        // Submit button
        $this->add_action_buttons(true, get_string('generate_ppt', 'local_pptgenerator'));
    }
}
