<?php
require_once('../../config.php');
require_once($CFG->dirroot . '/local/pptgenerator/form.php');
require_once($CFG->libdir . '/filelib.php');

$PAGE->set_url('/local/pptgenerator/index.php');
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('pluginname', 'local_pptgenerator'));
$PAGE->set_heading(get_string('pluginname', 'local_pptgenerator'));

$mform = new ppt_generator_form();

if ($mform->is_cancelled()) {
    redirect(new moodle_url('/'));
} else if ($data = $mform->get_data()) {
    $title = $data->title;
    $content = $data->content;
    $outline = $data->outline;
    $template = $data->template;

    // Fungsi untuk membuat PPT (panggil fungsi dari lib.php)
    $file_path = create_ppt($title, $content, $outline, $template);

    // Tampilkan hasil kepada pengguna
    echo $OUTPUT->header();
    echo $OUTPUT->heading(get_string('ppt_generated', 'local_pptgenerator'));
    echo html_writer::link($file_path, get_string('download_ppt', 'local_pptgenerator'));
    echo $OUTPUT->footer();
} else {
    echo $OUTPUT->header();
    $mform->display();
    echo $OUTPUT->footer();
}
