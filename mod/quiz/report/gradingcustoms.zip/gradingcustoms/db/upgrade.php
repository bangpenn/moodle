<?php

defined('MOODLE_INTERNAL') || die();

function xmldb_quiz_gradingcustoms_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    // Define the new version number.
    $newversion = 20240718;

    // Check if the current version is older than the new version.
    if ($oldversion < $newversion) {

        // Define table gradingform_customgraders to be updated.
        $table = new xmldb_table('gradingform_customgraders');

        // Add field grader_chatgpt.
        $field = new xmldb_field('grader_chatgpt', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'grader_head');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add field grade_chatgpt.
        $field = new xmldb_field('grade_chatgpt', XMLDB_TYPE_NUMBER, '10', null, null, null, null, 'grade_head');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Add field chatgpt_response.
        $field = new xmldb_field('chatgpt_response', XMLDB_TYPE_TEXT, null, null, null, null, null, 'grade_final');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Update the module version.
        upgrade_mod_savepoint(true, $newversion, 'quiz_gradingcustoms');
    }

    return true;
}
